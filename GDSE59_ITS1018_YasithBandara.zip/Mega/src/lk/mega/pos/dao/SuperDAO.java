package lk.mega.pos.dao;

public interface SuperDAO {
}
