package lk.mega.pos.dao.custom;

import lk.mega.pos.dao.CrudDAO;
import lk.mega.pos.entity.Customer;


public interface CustomerDAO extends CrudDAO<Customer,String> {
}
