package lk.mega.pos.bo;

public interface SuperBO {
}
